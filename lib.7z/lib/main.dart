// import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_sms/flutter_sms.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Home(),
    );
  }
}

String msg = "this is test message";
// List<String> listReceipents = ["03212275114", "03322819606"];
List<String> listReceipents = ["03212275114", "03322819606"];

class Home extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Send sms to multiple"),
      ),
      body: Container(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: RaisedButton(
              color: Theme.of(context).accentColor,
              padding: EdgeInsets.symmetric(vertical: 16),
              child: Text("Send Sms",
                  style: Theme.of(context).accentTextTheme.button),
              onPressed: () {
                // _sendSMS("This is a test message!", listReceipents);
                _sendSMS(msg, listReceipents);
              },
            ),
          ),
        ),
      ),
    );
  }
}

void _sendSMS(String msg, List<String> listReceipents) async {
  String _result = await sendSMS(message: msg, recipients: listReceipents)
      .catchError((onError) {
    print(onError);
  });
  print(_result);
}
// import 'dart:async';

// import 'package:flutter/material.dart';
// import 'package:flutter_sms/flutter_sms.dart';

// void main() => runApp(MyApp());

// class MyApp extends StatefulWidget {
//   @override
//   _MyAppState createState() => _MyAppState();
// }

// class _MyAppState extends State<MyApp> {
//   late TextEditingController _controllerPeople, _controllerMessage;
//   String? _message, body;
//   String _canSendSMSMessage = 'Check is not run.';
//   List<String> people = [];
//   bool sendDirect = false;

//   @override
//   void initState() {
//     super.initState();
//     initPlatformState();
//   }

//   Future<void> initPlatformState() async {
//     _controllerPeople = TextEditingController();
//     _controllerMessage = TextEditingController();
//   }

//   Future<void> _sendSMS(List<String> recipients) async {
//     try {
//       String _result = await sendSMS(
//         message: _controllerMessage.text,
//         recipients: recipients,
//         sendDirect: sendDirect,
//       );
//       setState(() => _message = _result);
//     } catch (error) {
//       setState(() => _message = error.toString());
//     }
//   }

//   Future<bool> _canSendSMS() async {
//     bool _result = await canSendSMS();
//     setState(() => _canSendSMSMessage =
//         _result ? 'This unit can send SMS' : 'This unit cannot send SMS');
//     return _result;
//   }

//   Widget _phoneTile(String name) {
//     return Padding(
//       padding: const EdgeInsets.all(3),
//       child: Container(
//           decoration: BoxDecoration(
//               border: Border(
//             bottom: BorderSide(color: Colors.grey.shade300),
//             top: BorderSide(color: Colors.grey.shade300),
//             left: BorderSide(color: Colors.grey.shade300),
//             right: BorderSide(color: Colors.grey.shade300),
//           )),
//           child: Padding(
//             padding: const EdgeInsets.all(4),
//             child: Column(
//               mainAxisAlignment: MainAxisAlignment.center,
//               mainAxisSize: MainAxisSize.min,
//               children: <Widget>[
//                 IconButton(
//                   icon: const Icon(Icons.close),
//                   onPressed: () => setState(() => people.remove(name)),
//                 ),
//                 Padding(
//                   padding: const EdgeInsets.all(0),
//                   child: Text(
//                     name,
//                     textScaleFactor: 1,
//                     style: const TextStyle(fontSize: 12),
//                   ),
//                 )
//               ],
//             ),
//           )),
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       debugShowCheckedModeBanner: false,
//       home: Scaffold(
//         appBar: AppBar(
//           title: const Text('SMS/MMS Example'),
//         ),
//         body: ListView(
//           children: <Widget>[
//             if (people.isEmpty)
//               const SizedBox(height: 0)
//             else
//               SizedBox(
//                 height: 90,
//                 child: Padding(
//                   padding: const EdgeInsets.all(3),
//                   child: ListView(
//                     scrollDirection: Axis.horizontal,
//                     children: List<Widget>.generate(people.length, (int index) {
//                       return _phoneTile(people[index]);
//                     }),
//                   ),
//                 ),
//               ),
//             ListTile(
//               leading: const Icon(Icons.people),
//               title: TextField(
//                 controller: _controllerPeople,
//                 decoration:
//                     const InputDecoration(labelText: 'Add Phone Number'),
//                 keyboardType: TextInputType.number,
//                 onChanged: (String value) => setState(() {}),
//               ),
//               trailing: IconButton(
//                 icon: const Icon(Icons.add),
//                 onPressed: _controllerPeople.text.isEmpty
//                     ? null
//                     : () => setState(() {
//                           people.add(_controllerPeople.text.toString());
//                           _controllerPeople.clear();
//                         }),
//               ),
//             ),
//             const Divider(),
//             ListTile(
//               leading: const Icon(Icons.message),
//               title: TextField(
//                 decoration: const InputDecoration(labelText: 'Add Message'),
//                 controller: _controllerMessage,
//                 onChanged: (String value) => setState(() {}),
//               ),
//             ),
//             const Divider(),
//             ListTile(
//               title: const Text('Can send SMS'),
//               subtitle: Text(_canSendSMSMessage),
//               trailing: IconButton(
//                 padding: const EdgeInsets.symmetric(vertical: 16),
//                 icon: const Icon(Icons.check),
//                 onPressed: () {
//                   _canSendSMS();
//                 },
//               ),
//             ),
//             SwitchListTile(
//                 title: const Text('Send Direct'),
//                 subtitle: const Text(
//                     'Should we skip the additional dialog? (Android only)'),
//                 value: sendDirect,
//                 onChanged: (bool newValue) {
//                   setState(() {
//                     sendDirect = newValue;
//                   });
//                 }),
//             Padding(
//               padding: const EdgeInsets.all(8),
//               child: ElevatedButton(
//                 style: ButtonStyle(
//                   backgroundColor: MaterialStateProperty.resolveWith(
//                       (states) => Theme.of(context).colorScheme.secondary),
//                   padding: MaterialStateProperty.resolveWith(
//                       (states) => const EdgeInsets.symmetric(vertical: 16)),
//                 ),
//                 onPressed: () {
//                   _send();
//                 },
//                 child: Text(
//                   'SEND',
//                   style: Theme.of(context).textTheme.displayMedium,
//                 ),
//               ),
//             ),
//             Visibility(
//               visible: _message != null,
//               child: Row(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: <Widget>[
//                   Expanded(
//                     child: Padding(
//                       padding: const EdgeInsets.all(12),
//                       child: Text(
//                         _message ?? 'No Data',
//                         maxLines: null,
//                       ),
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   void _send() {
//     if (people.isEmpty) {
//       setState(() => _message = 'At Least 1 Person or Message Required');
//     } else {
//       _sendSMS(people);
//     }
//   }
// }
